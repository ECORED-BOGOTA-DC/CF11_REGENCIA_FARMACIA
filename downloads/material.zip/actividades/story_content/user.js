function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5y30AHd7tGB":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

